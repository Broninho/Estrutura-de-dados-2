package App;
import Model.Entity.Pessoa;
/*import Model.DAO.ConectaBD;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
*/
import java.util.List;
import java.util.LinkedList;
import Model.DAO.PessoaDAO;
import java.util.Scanner;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;


public class App {

	public static int menu() {
		System.out.println("MENU");
		System.out.println("1 - INSERIR");
		System.out.println("2 - CONSULTAR TODOS");
		System.out.println("3 - CONSULTAR POR ID");
		System.out.println("4 - EXCLUIR POR ID");
		System.out.println("5 - ATUALIZAR DADOS");
		System.out.println("6 - SAIR");
		System.out.println("DIGITE A OPÇÃO: ");
		Scanner sc = new Scanner(System.in);
		return sc.nextInt();
	}
	
	public static String leString(String msg) {
		String valor = JOptionPane.showInputDialog(null,msg);
		return valor;
	}
	
	public static void metodoInserir() {
		String nome = leString("Digite Nome: ");
		String email = leString("Digite Email: ");
		Pessoa p = new Pessoa(nome,email);
		PessoaDAO pessoaDAO = new PessoaDAO();
		pessoaDAO.inserir(p);
	}
	
	public static Pessoa ConsultarID() {
		String idStr = leString("Digite id");
		// converter de String para int
		int id1 = Integer.parseInt(idStr);
		PessoaDAO dao = new PessoaDAO();
		Pessoa pess = dao.consultarPorId(id1);
		return pess;
	}
	
	public static void metodoExcluir() {
		String temp = leString("Digite id: ");
		int id = Integer.parseInt(temp); //CONVERTE PARA INTEIRO
		PessoaDAO pDAO = new PessoaDAO();
		if(pDAO.excluirReg(id)) {
			JOptionPane.showMessageDialog(null, new JTextArea("Registro "+id+" excluido."));
		}else {
			JOptionPane.showMessageDialog(null, new JTextArea("Registro "+id+" não encontrado."));
		}
		
	}
	
	public static void excluirPorID() {
		String idStr = leString("Digite id para deletar");
		// converter de String para int
		int id1 = Integer.parseInt(idStr);
		PessoaDAO dao = new PessoaDAO();
		boolean res = dao.deletarPorId(id1);
		String saida;
		if (res) {
			saida = "Deletado"; 
			JOptionPane.showMessageDialog(null, new JTextArea(saida));
		}else {
			System.out.println("Não existe esse registro");
		}
	}
	
	public static void atualizarDados(Pessoa p) {
		String novoN = leString("Novo nome: ");
		String novoE = leString("Novo email: ");
		JOptionPane.showMessageDialog(null, new JTextArea("Alterando nome de "+p.getNome()+" para: "+novoN));
		JOptionPane.showMessageDialog(null, new JTextArea("Alterando email de "+p.getEmail()+" para: "+novoE));
		p = new Pessoa(novoN,novoE);
		p.setNome(novoN);
		p.setEmail(novoE);
		PessoaDAO dao= new PessoaDAO();
		dao.atualizarDados(p);
	}
	
	public static void consultarTodos() {
		PessoaDAO pessoaDAO = new PessoaDAO();
		List<Pessoa> listaP = pessoaDAO.consultarTodos();
		if(!listaP.isEmpty()) {
			String saida = "";
			for(Pessoa ps: listaP) {
				saida += "ID: "+ps.getId() + " NOME: "+ps.getNome()+ " EMAIL: "+ps.getEmail() +" \n";
			}
			
			JOptionPane.showMessageDialog(null, new JTextArea(saida));
		}else {
			System.out.println("Lista vazia.");
		}
	}
	

	public static void main(String[] args) {
		int op;
		do {
			op = menu();
			switch (op) {
				case 1:
					metodoInserir();
					break;
				case 2:
					consultarTodos();
					break;
				case 3:
					Pessoa pess = ConsultarID(); 
					String saida;
					if (pess != null) {
						saida = "id\tnome\temail\n";
						saida += pess.getId()+"\t";
						saida = saida + pess.getNome()+"\t";
						saida += pess.getEmail()+"\n";
					}else {
						saida = "Registro nao foi localizado";
					}
					JOptionPane.showMessageDialog(null, new JTextArea(saida)); 
					break;
				case 4:
					//excluirPorID();
					metodoExcluir();
					break;
				case 5:
					Pessoa p = ConsultarID(); 
					if(p!= null) {
						atualizarDados(p);
					}else {
						JOptionPane.showMessageDialog(null, new JTextArea("Registro não encontrado.")); 
					}
					break;
				case  6:
					System.out.println("Saindo...");
				default:
					System.out.println("Opção invalida.");
			}
		}while (op != 6);
	}

	
}
