package App;
import Model.Entity.Produto;
/*import Model.DAO.ConectaBD;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
*/
import java.util.List;
import java.util.LinkedList;
import Model.DAO.ProdutoDAO;
import java.util.Scanner;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;


public class AppProduto {

	public static int menu() {
		System.out.println("MENU");
		System.out.println("1 - INSERIR");
		System.out.println("2 - CONSULTAR TODOS");
		System.out.println("3 - CONSULTAR POR ID");
		System.out.println("4 - CONSULTAR POR PLACA");
		System.out.println("5 - EXCLUIR POR ID");
		System.out.println("6 - ATUALIZAR DADOS");
		System.out.println("7 - SAIR");
		System.out.println("DIGITE A OPÇÃO: ");
		Scanner sc = new Scanner(System.in);
		return sc.nextInt();
	}
	
	public static String leString(String msg) {
		String valor = JOptionPane.showInputDialog(null,msg);
		return valor;
	}
	
	public static void metodoInserir() {
		String numChassi = leString("Digite numero do chassi: ");
		int chassi = Integer.parseInt(numChassi);
		String placa = leString("Digite a placa: ");
		String modelo = leString("Digite o modelo: ");
		String marca = leString("Digite a marca: ");
		String valor = leString("Digite o valor: ");
		float val = Float.parseFloat(valor);
		Produto p = new Produto(chassi,placa,modelo,marca,val);
		ProdutoDAO DAO = new ProdutoDAO();
		DAO.inserir(p);
	}
	
	public static Produto ConsultarID() {
		String idStr = leString("Digite id: ");
		int id1 = Integer.parseInt(idStr);
		ProdutoDAO dao = new ProdutoDAO();
		Produto prod = dao.consultarPorId(id1);
		return prod;
	}
	
	public static Produto ConsultarPlaca() {
		String idStr = leString("Digite a placa: ");
		ProdutoDAO dao = new ProdutoDAO();
		Produto prod = dao.consultarPorPlaca(idStr);
		return prod;
	}
	/*
	public static Produto ConsultarChassi() {
		String idStr = leString("Digite o numero do chassi: ");
		int id1 = Integer.parseInt(idStr);
		ProdutoDAO dao = new ProdutoDAO();
		Produto prod = dao.consultarPorId(id1);
		return prod;
	}
	*/
	public static void metodoExcluir() {
		String temp = leString("Digite id: ");
		int id = Integer.parseInt(temp); //CONVERTE PARA INTEIRO
		ProdutoDAO pDAO = new ProdutoDAO();
		if(pDAO.excluirReg(id)) {
			JOptionPane.showMessageDialog(null, new JTextArea("Registro "+id+" excluido."));
		}else {
			JOptionPane.showMessageDialog(null, new JTextArea("Registro "+id+" não encontrado."));
		}
		
	}
	
	public static void excluirPorID() {
		String idStr = leString("Digite id para deletar");
		// converter de String para int
		int id1 = Integer.parseInt(idStr);
		ProdutoDAO dao = new ProdutoDAO();
		boolean res = dao.excluirReg(id1);
		String saida;
		if (res) {
			saida = "Deletado"; 
			JOptionPane.showMessageDialog(null, new JTextArea(saida));
		}else {
			System.out.println("Não existe esse registro");
		}
	}
	
	public static void atualizarDados(Produto p) {
		String nChassi = leString("Atualizar chassi: ");
		int numChassi = Integer.parseInt(nChassi);
		String placa = leString("Atualizar placa: ");
		String modelo = leString("Atualizar modelo: ");
		String marca = leString("Atualizar marca: ");
		String valor = leString("Atualizar valor: ");
		float val = Float.parseFloat(valor);
		String saida;
		if (p != null) {
			saida = "Dados atualizados:\n";
			saida += "id\tNumero Chassi\tPlaca\tModelo\tMarca\tValor\n";
			saida += +p.getId()+"\t";
			saida += "De: "+p.getNumChassi()+" Para: "+nChassi+"\t\t";
			saida += "De: "+p.getPlaca()+" Para: "+ placa+"\t";
			saida += "De: "+p.getModelo()+" Para: "+ modelo+"\t";
			saida += "De: "+p.getMarca()+" Para: "+ marca+"\t";
			saida += "De: "+p.getValor()+" Para: "+valor+"\n";
		}else {
			saida = "Registro nao foi localizado";
		}
		JOptionPane.showMessageDialog(null, new JTextArea(saida)); 
		//p = new Produto(numChassi,placa,modelo,marca,val);
		p.setNumChassi(numChassi);
		p.setPlaca(placa);
		p.setModelo(modelo);
		p.setMarca(marca);
		p.setValor(val);
		ProdutoDAO dao= new ProdutoDAO();
		dao.atualizarDados(p);
	}
	
	public static void consultarTodos() {
		ProdutoDAO DAO = new ProdutoDAO();
		List<Produto> listaP = DAO.consultarTodos();
		if(!listaP.isEmpty()) {
			String saida = "";
			for(Produto ps: listaP) {
				saida += "ID: "+ps.getId() + "\n"
						+ "NUMERO CHASSI: "+ps.getNumChassi()+ "\n"
						+ "PLACA: "+ps.getPlaca() +"\n"
						+ "MODELO: "+ps.getModelo() +
						"\nMARCA: "+ ps.getMarca() + 
						"\nVALOR: "+ps.getValor()+"\n\n";
			}
			
			JOptionPane.showMessageDialog(null, new JTextArea(saida));
		}else {
			System.out.println("Lista vazia.");
		}
	}
	

	public static void main(String[] args) {
		int op;
		do {
			op = menu();
			switch (op) {
				case 1:
					metodoInserir();
					break;
				case 2:
					consultarTodos();
					break;
				case 3:
					Produto prod = ConsultarID(); 
					String saida;
					if (prod != null) {
						saida = "id\tNumero Chassi\tPlaca\tModelo\tMarca\tValor\n";
						saida += prod.getId()+"\t";
						saida = saida + prod.getNumChassi()+"\t\t";
						saida += prod.getPlaca()+"\t";
						saida += prod.getModelo()+"\t";
						saida += prod.getMarca()+"\t";
						saida += prod.getValor()+"\n";
					}else {
						saida = "Registro nao foi localizado";
					}
					JOptionPane.showMessageDialog(null, new JTextArea(saida)); 
					break;
				case 4:
					Produto prod2 = ConsultarPlaca(); 
					if (prod2 != null) {
						saida = "id\tNumero Chassi\tPlaca\tModelo\tMarca\tValor\n";
						saida += prod2.getId()+"\t";
						saida = saida + prod2.getNumChassi()+"\t\t";
						saida += prod2.getPlaca()+"\t";
						saida += prod2.getModelo()+"\t";
						saida += prod2.getMarca()+"\t";
						saida += prod2.getValor()+"\n";
					}else {
						saida = "Registro nao foi localizado";
					}
					JOptionPane.showMessageDialog(null, new JTextArea(saida)); 
					break;
				case 5:
					//excluirPorID();
					metodoExcluir();
					break;
				case 6:
					Produto p = ConsultarID(); 
					if(p!= null) {
						atualizarDados(p);
					}else {
						JOptionPane.showMessageDialog(null, new JTextArea("Registro não encontrado.")); 
					}
					break;
				case  7:
					System.out.println("Saindo...");
				default:
					System.out.println("Opção invalida.");
			}
		}while (op != 6);
	}

	
}
