package Model.Entity;

public class Produto {
	private int id;
	private int numChassi;
	private String placa;
	private String modelo;
	private String marca;
	private float valor;
	
	public Produto() {
		// TODO Auto-generated constructor stub
	}
	public Produto(int numChassi, String placa, String modelo, String marca, float valor) {
		this.modelo = modelo;
		this.marca = marca;
		this.numChassi = numChassi;
		this.valor = valor;
		this.placa = placa;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getNumChassi() {
		return numChassi;
	}

	public void setNumChassi(int numChassi) {
		this.numChassi = numChassi;
	}

	public String getPlaca() {
		return placa;
	}

	public void setPlaca(String placa) {
		this.placa = placa;
	}

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public float getValor() {
		return valor;
	}

	public void setValor(float valor) {
		this.valor = valor;
	}

}
