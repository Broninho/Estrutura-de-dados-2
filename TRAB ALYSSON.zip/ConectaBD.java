package Model.DAO;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import Model.Entity.Pessoa;
                                      
public class ConectaBD {
	private Connection conexao;
	
	public ConectaBD() {
		String url = "jdbc:mariadb://localhost:3306/conectado";
		String user = "root";
		String pass = "root";
		try {
			conexao = DriverManager.getConnection(url, user, pass);
			System.out.println("Conectado.");
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
	}
	
	public Connection getConexao() {
		return conexao;
	}
	

}
