package Model.DAO;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;


import Model.DAO.ConectaBD;
import Model.Entity.Pessoa;

public class PessoaDAO {
	//CRUD
	//C - CREATE | R - RETRIEVE | U - UPDATE | D - DELETE
	
	public Pessoa consultar() {
		//SELECT
		return null;
	}
	
	
	public Pessoa consultarPorId(int id) {
	    ConectaBD con = new ConectaBD();
	    String sql = "SELECT * FROM pessoa WHERE id = ?";
	    Pessoa p = null;
	    try {
	        PreparedStatement pst = con.getConexao().prepareStatement(sql);
	        pst.setInt(1, id);
	        ResultSet rs = pst.executeQuery();
	        if (rs.next()) {
	        	String nome = rs.getString("nome");
	        	String email = rs.getString("email");
	            p = new Pessoa();
	            p.setId(rs.getInt("id"));
	            p.setEmail(email);
	            p.setNome(nome);
	        }
	    } catch (SQLException e) {
	        System.out.println(e.getMessage());
	    } 
	    return p;
	}
	
	public boolean excluirReg(int id) {
		ConectaBD con = new ConectaBD();
		String sql = "DELETE FROM pessoa WHERE id = ?";
		try {
			PreparedStatement pst = con.getConexao().prepareStatement(sql);
			pst.setInt(1, id);
			pst.execute();
			int linhas = pst.executeUpdate();
			return pst.getUpdateCount()>0;
			
		}catch(SQLException e) {
			System.out.println(e.getMessage());
		}
		return false;
	}
	
	public boolean atualizarDados(Pessoa p) {
		ConectaBD con = new ConectaBD();
		String sql = "UPDATE pessoa set nome = ?, email = ? where id = ?";
		try {
			PreparedStatement pst = con.getConexao().prepareStatement(sql);
			pst.setString(1, p.getNome());
			pst.setString(2, p.getEmail());
			pst.setInt(3, p.getId());
			return pst.executeUpdate()>0;
			
		}catch(SQLException e) {
			System.out.println(e.getMessage());
		}
		return false;
	}
	
	public boolean deletarPorId(int id) {
		ConectaBD con = new ConectaBD();
	    String sql = "DELETE FROM pessoa WHERE id = ?";
	    try {
	        PreparedStatement pst = con.getConexao().prepareStatement(sql);
	        pst.setInt(1, id);
	        pst.execute();
	    } catch (SQLException e) {
	        System.out.println(e.getMessage());
	    } 
	    return true;
	}

	
	public List<Pessoa> consultarTodos(){
		ConectaBD con = new ConectaBD();
		String sql = "SELECT * FROM pessoa";
		List<Pessoa> lista = new LinkedList<Pessoa>();
		try {
			PreparedStatement pst = con.getConexao().prepareStatement(sql);
			ResultSet rs = pst.executeQuery();
			while(rs.next()) {
				Pessoa pessoa = new Pessoa();
				int id = rs.getInt("id");
				String nome = rs.getString("nome");
				String email = rs.getString("email");
				pessoa.setId(id);
				pessoa.setNome(nome);
				pessoa.setEmail(email);
				lista.add(pessoa);
			}
			
		}catch(SQLException e) {
			System.out.println(e.getMessage());
		}
		
		return lista;
	}
	
	public void inserir(Pessoa p) {
		ConectaBD  conn = new ConectaBD();
		String sql = "INSERT INTO pessoa (nome,email) VALUES(?,?)";
		try {
			PreparedStatement prep = conn.getConexao().prepareStatement(sql);
			prep.setString(1, p.nome);
			prep.setString(2, p.email);
			prep.execute();
			System.out.println("Inserido.");
		} catch (SQLException e) {	
			System.out.println(e.getMessage());
		}
		
		
	}
	
	public void update() {
		
	}
	
	public void delete() {
		
	}
}

