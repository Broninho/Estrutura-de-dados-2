package Model.Entity;
import Model.DAO.PessoaDAO;

public class Pessoa {
	public int id;
	public String nome;
	public String email;
	
	public Pessoa() {
		
	}
	
	public Pessoa(String nome, String email) {
		this.nome = nome;
		this.email = email;
	}

	public int getId() {
		return id;
	}

	public String getNome() {
		return nome;
	}

	public String getEmail() {
		return email;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	public void inserir() {
		PessoaDAO pessoaDAO = new PessoaDAO();
		pessoaDAO.inserir(this);
	}

}
