package Model.DAO;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;


import Model.DAO.ConectaBD;
import Model.Entity.Pessoa;
import Model.Entity.Produto;

public class ProdutoDAO {
	//CRUD
	//C - CREATE | R - RETRIEVE | U - UPDATE | D - DELETE
	
	public Produto consultar() {
		//SELECT
		return null;
	}
	
	public Produto consultarPorId(int id) {
	    ConectaBD con = new ConectaBD();
	    String sql = "SELECT * FROM produto WHERE id = ?";
	    Produto p = null;
	    try {
	        PreparedStatement pst = con.getConexao().prepareStatement(sql);
	        pst.setInt(1, id);
	        ResultSet rs = pst.executeQuery();
	        if (rs.next()) {
	        	int numChassi = rs.getInt("chassi");
	        	String placa = rs.getString("placa");
	        	String modelo = rs.getString("modelo");
	        	String marca = rs.getString("marca");
	        	Float valor = rs.getFloat("valor");
	            p = new Produto();
	            p.setId(rs.getInt("id"));
	            p.setId(id);
	            p.setNumChassi(numChassi);
	            p.setPlaca(placa);
	            p.setModelo(modelo);
	            p.setMarca(marca);
	            p.setValor(valor);
	        }
	    } catch (SQLException e) {
	        System.out.println(e.getMessage());
	    } 
	    return p;
	}
	
	public Produto consultarPorPlaca(String pl) {
	    ConectaBD con = new ConectaBD();
	    String sql = "SELECT * FROM produto WHERE placa = ?";
	    Produto p = null;
	    try {
	        PreparedStatement pst = con.getConexao().prepareStatement(sql);
	        pst.setString(1, pl);
	        ResultSet rs = pst.executeQuery();
	        if (rs.next()) {
	            p = new Produto();
	            p.setId(rs.getInt("id"));
	            p.setNumChassi(rs.getInt("chassi"));
	            p.setPlaca(rs.getString("placa"));
	            p.setModelo(rs.getString("modelo"));
	            p.setMarca(rs.getString("marca"));
	            p.setValor(rs.getFloat("valor"));
	        }
	    } catch (SQLException e) {
	        System.out.println(e.getMessage());
	    } 
	    return p;
	}
	
	public boolean excluirReg(int id) {
		ConectaBD con = new ConectaBD();
		String sql = "DELETE FROM produto WHERE id = ?";
		try {
			PreparedStatement pst = con.getConexao().prepareStatement(sql);
			pst.setInt(1, id);
			pst.execute();
			return pst.getUpdateCount()>0;
			
		}catch(SQLException e) {
			System.out.println(e.getMessage());
		}
		return false;
	}
	
	public boolean atualizarDados(Produto p) {
		ConectaBD con = new ConectaBD();
		String sql = "UPDATE produto set chassi = ?, placa = ?, modelo = ?,"
				+ " marca = ?, valor = ? where id = ?";
		try {
			PreparedStatement pst = con.getConexao().prepareStatement(sql);
			pst.setInt(1, p.getNumChassi());
			pst.setString(2, p.getPlaca());
			pst.setString(3, p.getModelo());
			pst.setString(4, p.getMarca());
			pst.setFloat(5, p.getValor());
			pst.setInt(6, p.getId());
			return pst.executeUpdate()>0;
			
		}catch(SQLException e) {
			System.out.println(e.getMessage());
		}
		return false;
	}
	
	public List<Produto> consultarTodos(){
		ConectaBD con = new ConectaBD();
		String sql = "SELECT * FROM produto";
		List<Produto> lista = new LinkedList<Produto>();
		try {
			PreparedStatement pst = con.getConexao().prepareStatement(sql);
			ResultSet rs = pst.executeQuery();
			while(rs.next()) {
				Produto prod = new Produto();
				int id = rs.getInt("id");
				int numChassi = rs.getInt("chassi");
				String placa = rs.getString("placa");
				String modelo = rs.getString("modelo");
				String marca = rs.getString("marca");
				float valor = rs.getFloat("valor");
				prod.setId(id);
				prod.setNumChassi(numChassi);
				prod.setPlaca(placa);
				prod.setModelo(modelo);
				prod.setMarca(marca);
				prod.setValor(valor);
				lista.add(prod);
			}
			
		}catch(SQLException e) {
			System.out.println(e.getMessage());
		}
		
		return lista;
	}
	
	public void inserir(Produto p) {
		ConectaBD  conn = new ConectaBD();
		String sql = "INSERT INTO produto (chassi,placa,modelo,marca,valor) VALUES(?,?,?,?,?)";
		try {
			PreparedStatement prep = conn.getConexao().prepareStatement(sql);
			prep.setInt(1, p.getNumChassi());
			prep.setString(2, p.getPlaca());
			prep.setString(3, p.getModelo());
			prep.setString(4, p.getMarca());
			prep.setFloat(5, p.getValor());
			prep.execute();
			System.out.println("Inserido.");
		} catch (SQLException e) {	
			System.out.println(e.getMessage());
		}
		
		
	}
	
	public void update() {
		
	}
	
	public void delete() {
		
	}
}
